// const sellerController=(req,res)=>{
//     res.render('pages/Become_sell');
// }
// export {sellerController}
const vregController=(req,res)=>{
    res.render('pages/Vendor_registration');
}
export{vregController}
const vproductController=(req,res)=>{
    res.render('pages/Vendor_product');
}
export{vproductController}
 
const vprofileController=(req,res)=>{
    res.render('pages/Vendor_profile');
}
export{vprofileController}
