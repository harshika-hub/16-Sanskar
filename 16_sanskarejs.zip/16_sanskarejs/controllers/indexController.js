

const homeController=(req,res)=>{
    res.render('pages/home');
}
export {homeController}

const blogController=(req,res)=>{
    res.render('pages/Blogs');
}
export {blogController}


const sellController=(req,res)=>{
    res.render('pages/Become_sell');
}
export {sellController}
const aboutController=(req,res)=>{
    res.render('pages/About')

}
export{aboutController}

const registrationController=(req,res)=>{
    res.render('pages/Registration');
}
export{registrationController}

