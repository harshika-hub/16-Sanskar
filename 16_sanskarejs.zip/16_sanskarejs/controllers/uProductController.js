
const uProductController = (req, res) => {
    res.render('pages/userProduct');
}
export { uProductController }

const ucartController = (req, res) => {
    res.render('pages/Cart');
    console.log(req.cookies)
}
export { ucartController }

const uprofileController=(req,res)=>{
    res.render('pages/User_profile');
}
export {uprofileController}
const uloginController=(req,res)=>{
    res.render('pages/user_login');
}
export {uloginController}


