
const adashController=(req,res)=>{
    res.render('pages/Admin_dash');
}
export{adashController}

const auserController=(req,res)=>{
    res.render('pages/User_details');
}
export{auserController}

const avendorController=(req,res)=>{
    res.render('pages/Vendor_details');
}
export{avendorController}

const aproductController=(req,res)=>{
    res.render('pages/Added_product');
}
export{aproductController}

const aorderController=(req,res)=>{
    res.render('pages/Orders');
}
export{aorderController}

