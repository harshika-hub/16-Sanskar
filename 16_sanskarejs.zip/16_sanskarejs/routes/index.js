import express from 'express'
const router=express.Router()
import {homeController, blogController,sellController,aboutController,registrationController } from '../controllers/indexController.js'
router.get('/', homeController)
router.get('/Blogs',blogController)
router.get('/Become_sell',sellController)
router.get('/About',aboutController)
router.get('/Registration',registrationController)

export default router