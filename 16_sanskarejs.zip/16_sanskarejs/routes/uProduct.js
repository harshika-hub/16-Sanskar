import express from 'express'
const router=express.Router()
import { uProductController,ucartController,uprofileController,uloginController } from '../controllers/uProductController.js'
// import { ucart } from '../controllers/uProductController.js'
router.get('/',uProductController)
router.get('/Cart',ucartController)
router.get('/User_profile', uprofileController)
router.get('/user_login',uloginController);
export default router

