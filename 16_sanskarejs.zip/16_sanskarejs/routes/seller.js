import express from 'express'
const router=express.Router()
import { vregController,vproductController,vprofileController } from '../controllers/sellerController.js'
router.get('/', vregController)
router.get('/Vendor_product', vproductController)

router.get('/Vendor_profile', vprofileController)
export default router 