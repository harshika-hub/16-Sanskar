import express from 'express'
const router=express.Router()
import { adashController,auserController,avendorController,aproductController,aorderController } from '../controllers/adminController.js'
router.get('/', adashController)
router.get('/User_details', auserController)
router.get('/Vendor_details', avendorController)
router.get('/Added_product', aproductController)
router.get('/Orders', aorderController)

export default router 